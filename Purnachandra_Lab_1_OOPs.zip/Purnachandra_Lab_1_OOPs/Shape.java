package Lab_1_OOPS;

public class Shape {

	String color;
	
	public Shape(String color) {
		this.color = color;
	}
	
	public double calculateArea() {
		return 0;
	}
	
	public double calculatePerimeter() {
		return 0;
	}
	
	public void display() {
		System.out.println("this is a shape with color" + this.color);
	}
}
